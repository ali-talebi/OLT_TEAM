import pytest  
import testlink

def pytest_addoption(parser) : 
    parser.addoption("--name" , action = "store" , default = "default_value" , help = "Description of myargs" )
    parser.addoption("--server_url"  , action = "store" , default = "http://195.201.231.223:8080/lib/api/xmlrpc/v1/xmlrpc.php" , help = "Description of myargs" )
    parser.addoption("--devkey_user" , action = "store" , default = "2a40335f269615f7ebcef5af20141167" , help = "Description of myargs" )


@pytest.fixture(scope="session")
def cli_f(request) : 
    print("\n I am CLI F\n ") 

    server_url = request.config.getoption("--server_url")
    devk_user  = request.config.getoption("--devkey_user")

    TESTLINK_API_PYTHON_SERVER_URL =server_url
    TESTLINK_API_PYTHON_DEVKEY     = devk_user  
    client = testlink.TestLinkHelper().connect(testlink.TestlinkAPIClient) 

    print(client)






