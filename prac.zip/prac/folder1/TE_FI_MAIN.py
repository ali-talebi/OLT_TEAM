
import pytest 


@pytest.mark.usefixtures("cli_f")
def TE_FU_MAIN_FUNCTION(cli_f , request ):

    print("\n I am in Main Function \n ")