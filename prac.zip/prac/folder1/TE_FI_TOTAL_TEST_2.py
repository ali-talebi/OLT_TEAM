
import pytest 
import testlink 

@pytest.mark.vlan 
def TE_FU_TEST1(cli_f) : 
    print("I am in TEST1 \n")
    assert True  

@pytest.mark.tcont 
def TE_FU_TEST2(cli_f) :
    print("\nI an in TEST2 \n")
    assert True 