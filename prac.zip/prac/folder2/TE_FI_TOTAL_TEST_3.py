
import pytest  

@pytest.mark.other 
@pytest.mark.usefixtures("cli_f")
def TE_FU_GETER(cli_f , request ) :
    name = request.config.getoption("--name")
    print("\nI am in GETER TEST\n")
    print(f" I get name : {name}")
    assert True 

